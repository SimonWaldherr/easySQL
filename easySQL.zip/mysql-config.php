<?php

/*
 *
 * easySQL
 * 
 * Repo: https://github.com/SimonWaldherr/easySQL
 * Demo: http://cdn.simon.waldherr.eu/projects/easySQL/
 * License: MIT
 * Version: 0.4.1
 *
 */


$mysqlarray[0][0] = 'localhost';
$mysqlarray[0][1] = 'dbo00046793';
$mysqlarray[0][2] = 'admin';
$mysqlarray[0][3] = 'db00046793';
$mysqlarray[1] = '`db00046793`.`db00046794`';

?>
